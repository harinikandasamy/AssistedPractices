export interface myaadhar{
id:number;
fullname:string;
gender:string;
address:string;
dob:string;
phone:number;
email:string;
imageUrl:string;
}